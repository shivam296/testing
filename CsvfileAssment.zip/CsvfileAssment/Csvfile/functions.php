    <?php
include 'db.php';
$con = getdb();
if (isset($_POST["Import"])) {


$mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
if(in_array($_FILES['file']['type'],$mimes)){
   $filename = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        $file = fopen($filename, "r");
        $count = 0;
        
        while (($getData = fgetcsv($file, ",")) !== FALSE) {
            $count++;

            if ($count >= 7) {
                 
                $feetype = "INSERT into fee_types (moduleid,sequenceNo,feetypename,feetypenameTally) 
                       values ('".$getData[0]."','".$getData[0]."','".$getData[16]."','".$getData[16]."');";
                $finacial_trans = "INSERT into financialtran (moduleid,status,due,due_reverse,concession,concession_reverse,Opening_balance) 
                       values ('".$getData[0]."','".$getData[9]."','".$getData[17]."','".$getData[17]."','".$getData[19]."','".$getData[21]."','".$getData[18]."');";

                $finacial_trans_details = "INSERT into financialtrandetail (financialtranid,moduleid,amount,headType) 
                       values ('".$getData[0]."','".$getData[0]."','".$getData[18]."','".$getData[16]."');"; 
                $common_fee = "INSERT into common_fee_collection (admno,moduleid,remark) 
                       values ('".$getData[8]."','".$getData[0]."','".$getData[26]."');";

                $common_fee_collection = "INSERT into common_fee_collection_headwise (moduleid,receiptid,headType,amount) 
                       values ('".$getData[0]."','".$getData[6]."','".$getData[16]."','".$getData[18]."');";              
    
                 $result = mysqli_query($con, $feetype);
                 $result = mysqli_query($con, $finacial_trans);
                 $result = mysqli_query($con, $finacial_trans_details);
                 $result = mysqli_query($con, $common_fee);
                 $result = mysqli_query($con, $common_fee_collection);
                 
            } else {
                continue;
            }


        }
        if(!isset($result))
            {
                 echo "<script type=\"text/javascript\">
                  alert(\"Invalid File:Please Upload CSV File.\");
                  window.location = \"index.php\"
                  </script>"; 
            }
            else {
                print('file uploaded successfully'); 
            }
        fclose($file);
    }
} else {
  echo "<script type=\"text/javascript\">
                  alert(\"Invalid File:Please Upload CSV File.\");
                  window.location = \"index.php\"
                  </script>";
}

   
}
?>